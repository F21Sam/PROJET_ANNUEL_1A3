<footer class="footer py-4">
    <div class="container">
        <ul class="nav nav-footer justify-content-center ">
            <li class="nav-item">
                <a href="#" class="nav-link pe-0 text-muted" target="_blank">Ensemble, sauvons les animaux !❤✨</a>
            </li>
        </ul>
        <ul class="nav nav-footer justify-content-center ">
            <li class="nav-item">
                <a href="#" class="nav-link pe-0 text-muted" target="_blank">© Amimal le refuge 2024 - CGV - Mentions Légales </a>
            </li>
        </ul>
    </div> 
</footer>

<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/perfect-scrollbar.min.js"></script>
<script src="assets/js/smooth-scrollbar.min.js"></script>
</body>

</html>
