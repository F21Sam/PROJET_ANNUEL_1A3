<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Email</title>
</head>
<body>
    <form class="" action="newsletter.php" method="POST">
        Subject <input type="text" name="subject" value=""><br>
        Message <input type="text" name="message" value=""><br>
        <button type="submit" name="send">Send</button>
    </form>
</body>
</html>
