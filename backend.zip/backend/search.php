<?php 
require('includes/dbpa.php');

$query = isset($_GET['q']) ? $_GET['q'] : '';








?>